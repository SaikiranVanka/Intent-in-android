## 1.0.3 (2015-11-11)
 
* remove option to set the 'author'

## 1.0.2 (2015-09-07)

* add concrete intent builder for enex import

## 1.0.1 (2015-05-26)

* pick note
* add attachment in new note in demo

## 1.0.0 (2015-05-13)

* create new note
* search with query parameter
* view an existing note
* take new snapshot
* record voice note
* open search UI